package com.example.flutter_water_tank

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
