# jhwutils
Various utilities for teaching.

Install:

    pip install -U https://github.com/johnhw/jhwutils/zipball/master

### External contributing packages
* `transformations.py` by Christoph Gohlke, redistributed under the BSD license